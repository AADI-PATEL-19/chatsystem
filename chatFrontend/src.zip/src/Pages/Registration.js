import React from 'react'
import RegisterComponent from '../Components/RegisterComponent'

export default function Registration() {
  return (
    <div>
      <RegisterComponent/>
    </div>
  )
}
