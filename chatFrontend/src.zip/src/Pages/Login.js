import React from 'react'
import LoginComponent from '../Components/LoginComponent'

export default function Login() {
  return (
    <div>
        <LoginComponent/>
    </div>
  )
}
